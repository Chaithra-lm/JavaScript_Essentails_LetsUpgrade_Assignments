/*External JS file*/
/* Print 5 stars in same line . */

var str="";
for(var i=0; i<5;i++)
{
 str+="* "
}
console.log(str);
