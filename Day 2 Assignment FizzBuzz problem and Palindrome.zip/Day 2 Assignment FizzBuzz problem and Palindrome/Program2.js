/*External JS file*/
/*Fizz Buzz problem 1 to 100*/


for (var i=1; i < 101; i++)
{
    if (i % 15 == 0)
     console.log("FizzBuzz");
    else if (i % 3 == 0)
     console.log("Fizz");
    else if (i % 5 == 0) 
    console.log("Buzz");
    else console.log(i);
}

/* find palindrome words in a given string. */

function checkPalin(word)
{
    var n = word.length
    word = word.toLowerCase();
 
    for (var i = 0; i < n; i++,n--)
    if (word[i] != word[n - 1])
        return false;
    else 
    return true;
}
 
// Function to count palindrome words
function countPalin( str)
{        
    // to check last word for palindrome
    str = str + " ";
     
    // to store each word
    var word = "";
    var count = 0;
    for (var i = 0; i < str.length; i++)
    {
        var ch = str[i];
         
        // extracting each word
        if (ch != ' ')
            word = word + ch;
        else {
            if (checkPalin(word))
                count++;
            word = "";
        }
    }
     
    return count;
}
     
console.log("Madam Arora teaches malayalam contains "+countPalin("Madam Arora teaches malayalam")+" palindrome words");